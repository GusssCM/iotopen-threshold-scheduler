
-- Global tables
local topicArmed = {}
local topicFunction = {}
local edgeTrigger = {}

log.i("[INIT] Starting app")

-- DST-aware date function
function dst_date()
    local time = os.date("!*t")
    local offset = 1

    if time.month >= 4 and time.month <= 9 then
        offset = 2
    elseif time.month == 3 and time.day >= 25 and time.wday == 1 then
        offset = 2
    elseif time.month == 10 and time.day >= 25 and time.wday == 1 then
        offset = 1
    end

    return os.date("!*t", os.time() + offset * 3600)
end

-- Date interval check based on MMDD
local function inDateRange()
    local now = os.date("!*t")
    local nowMD = now.month * 100 + now.day

    local function parseMonthDay(dateStr)
        local _, m, d = dateStr:match("(%d+)%-(%d+)%-(%d+)")
        if m and d then
            return tonumber(m) * 100 + tonumber(d)
        end
        return nil
    end

    local start = parseMonthDay(cfg.date_start)
    local end_ = parseMonthDay(cfg.date_end)

    if not start or not end_ then
        log.e("❌ Invalid date format. Use YYYY-MM-DD.")
        return false
    end

    log.d("📅 Today: %d, Start: %d, End: %d", nowMD, start, end_)

    if start <= end_ then
        return nowMD >= start and nowMD <= end_
    else
        return nowMD >= start or nowMD <= end_
    end
end

-- Time and weekday check
function inSchedule()
    local date = dst_date()

    local has_schedule = cfg.sunday ~= nil or cfg.monday ~= nil or cfg.tuesday ~= nil or
                         cfg.wednesday ~= nil or cfg.thursday ~= nil or cfg.friday ~= nil or
                         cfg.saturday ~= nil or cfg.time_start ~= nil or cfg.time_end ~= nil

    if not has_schedule then
        log.d("📆 No weekday or time limit - allowed whole day")
        return true
    end

    local weekday_allowed = true
    if cfg.sunday == false and date.wday == 1 then weekday_allowed = false end
    if cfg.monday == false and date.wday == 2 then weekday_allowed = false end
    if cfg.tuesday == false and date.wday == 3 then weekday_allowed = false end
    if cfg.wednesday == false and date.wday == 4 then weekday_allowed = false end
    if cfg.thursday == false and date.wday == 5 then weekday_allowed = false end
    if cfg.friday == false and date.wday == 6 then weekday_allowed = false end
    if cfg.saturday == false and date.wday == 7 then weekday_allowed = false end

    if not weekday_allowed then
        log.d("⏰ Today is not an active weekday")
        return false
    end

    local time_start = cfg.time_start or 0
    local time_end = cfg.time_end or 24
    local in_schedule = time_start <= date.hour and date.hour < time_end

    log.d("⏱️ Hour: %d, Period: %d-%d, Side: %s", date.hour, time_start, time_end, cfg.side)
    return (cfg.side == 'inom') and in_schedule or not in_schedule
end

-- Trigger handler
function handleTrigger(topic, payload, retained)
    local success, data = pcall(function() return json:decode(payload) end)
    if not success or not data then
        log.e("❌ JSON decode error on topic: %s", topic)
        return
    end

    if cfg.overOrUnder == "under" then
        topicArmed[topic] = data.value < cfg.threshold
    elseif cfg.overOrUnder == "over" then
        topicArmed[topic] = data.value > cfg.threshold
    end

    sendNotificationIfArmed(topic, data.value, cfg.overOrUnder)
end

-- Notification
function sendNotificationIfArmed(topic, value, action)
    if not cfg.notification_output then
        log.w("⚠️ No notification output selected")
        return
    end
    if not inSchedule() or not inDateRange() then
        log.i("⛔ Outside active time or date range")
        return
    end

    local func = topicFunction[topic]
    if not func then
        log.e("❌ No function found for topic: %s", topic)
        return
    end

    local dev = nil
    local ok, result = pcall(function()
        return edge.findDevice(tonumber(func.meta.device_id))
    end)
    if ok then dev = result end

    local armed = topicArmed[topic]
    local sent = edgeTrigger[topic]

    if armed then
        if sent then
            log.i("🔁 Notification already sent")
            return
        end

        local payloadData = {
            value = value,
            action = action,
            firing = func.meta.name,
            unit = func.meta.unit,
            note = func.meta.note,
            func = func,
            device = dev,
            threshold = cfg.threshold
        }

        log.i("📤 Sending notification (%.2f)", value)
        local ok, err = pcall(function()
            lynx.notify(cfg.notification_output, payloadData)
        end)

        if not ok then
            log.e("❌ Failed to send notification message: %s", tostring(err))
        else
            log.i("✅ Notification sent to output ID %s for %.2f %s (%s) – threshold: %s %.2f",
                tostring(cfg.notification_output),
                value,
                func.meta.unit or "",
                func.meta.name or topic,
                cfg.overOrUnder,
                cfg.threshold)
        end

        edgeTrigger[topic] = true
    else
        log.d("✅ Condition not met – nothing sent")
        edgeTrigger[topic] = false
    end
end

-- MQTT subscription
function setupFunctionSubscriptions()
    topicFunction = {}
    local all = lynx.getFunctions()
    local selected = {}
    for _, id in ipairs(cfg.trigger_functions or {}) do
        selected[tostring(id)] = true
    end

    for _, fn in ipairs(all) do
        if selected[tostring(fn.id)] then
            local topic = fn.meta and fn.meta.topic_read
            if topic then
                topicFunction[topic] = fn
                mq:sub(topic, 0)
                mq:bind(topic, handleTrigger)
                log.i("📡 Listening on: %s", topic)
            else
                log.w("⚠️ Function %s is missing topic_read", tostring(fn.id))
            end
        end
    end
end

-- Start
function onStart()
    log.i("🚀 Scheduler app starting")
    if not cfg or not cfg.trigger_functions then
        log.e("❌ Configuration is missing")
        return
    end
    setupFunctionSubscriptions()
end
